/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */ 

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.get('/mobile/custom/BankingCC/components', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = [
					  {
					    "componentName": "mcs.IntegrationApi",
					    "channels": {
					      "facebook": "1.0"
					    },
					    "componentProperties": {
					      "location": { "type": "string", "required": true }
					    },
					    "supportedActions": [
					    ]
					  },
					  {
					    "componentName": "mcs.AnotherApi",
					    "channels": {
					      "facebook": "1.0"
					    },
					    "componentProperties": {
					      "variable": { "type": "string", "required": true }
					    },
					    "supportedActions": [
					    ]
					  }
					];
			}
		}
		res.status(statusCode).send(result);
	});

	service.post('/mobile/custom/BankingCC/components/:componentName', function(req,res) {
		var result = {};
		var statusCode = 201;
		res.status(statusCode).send(result);
	});

};
