/**
 * The ExpressJS namespace.
 * @external ExpressApplicationObject
 * @see {@link http://expressjs.com/3x/api.html#app}
 */ 

/**
 * Mobile Cloud custom code service entry point.
 * @param {external:ExpressApplicationObject}
 * service 
 */
module.exports = function(service) {


	/**
	 *  The file samples.txt in the archive that this file was packaged with contains some example code.
	 */


	service.get('/mobile/custom/BankingApi/accounts', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = [
					  {
					    "type": "checking",
					    "id": "903423-123"
					  },
					  {
					    "type": "savings",
					    "id": "258293-832"
					  },
					  {
					    "type": "401k",
					    "id": "4321-1234"
					  },
					  {
					    "type": "stock",
					    "id": "67632-2332"
					  },
					  {
					    "type": "credit card",
					    "id": "4352-3423-1234-5239",
					    "limit": 5000
					  }
					];
			}
		}
		res.status(statusCode).send(result);
	});

	service.post('/mobile/custom/BankingApi/accounts/:id/transactions', function(req,res) {
		var result = {};
		var statusCode = 201;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = {
					  "date": "2016-01-20",
					  "type": "debit",
					  "category": "payment",
					  "description": "Payment for 01/15 billing cycle",
					  "amount": 230.45
					};
			}
		}
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/BankingApi/accounts/:id/transactions', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = [
					  {
					    "date": "2016-01-20",
					    "type": "payment",
					    "category": "billing cycle",
					    "description": "Payment for 01/15 billing cycle",
					    "fromAccountType": "credit card",
					    "amount": 230.45
					  },
					  {
					    "date": "2016-01-22",
					    "type": "debit",
					    "category": "travel",
					    "description": "Merchant 1",
					    "fromAccountType": "credit card",
					    "amount": -103.28
					  },
					  {
					    "date": "2016-03-20",
					    "type": "debit",
					    "category": "gas",
					    "description": "Merchant 2",
					    "fromAccountType": "credit card",
					    "amount": -8.25
					  },
					  {
					    "date": "2016-04-15",
					    "type": "debit",
					    "category": "restaurants",
					    "description": "Merchant 3",
					    "fromAccountType": "credit card",
					    "amount": -60
					  },
					  {
					    "date": "2016-04-25",
					    "type": "credit",
					    "category": "restaurants",
					    "description": "Merchant 3, refund",
					    "fromAccountType": "credit card",
					    "amount": 20
					  },
					  {
					    "date": "2016-04-28",
					    "type": "debit",
					    "category": "retail",
					    "description": "Merchant 4, retail",
					    "fromAccountType": "credit card",
					    "amount": -234
					  }
					];
			}
		}
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/BankingApi/stats', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = {
					  "categoryDimension": "category",
					  "account": "4352-3423-1234-5239",
					  "metrics": [
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-01-20",
					      "type": "debit",
					      "category": "payment",
					      "description": "Payment for 01/15 billing cycle",
					      "amount": 230.45
					    },
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-01-22",
					      "type": "debit",
					      "category": "travel",
					      "description": "Merchant 1",
					      "amount": -103.28
					    },
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-03-20",
					      "type": "debit",
					      "category": "gas",
					      "description": "Merchant 2",
					      "amount": -8.25
					    },
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-04-15",
					      "type": "debit",
					      "category": "restaurants",
					      "description": "Merchant 3",
					      "amount": -60
					    },
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-04-25",
					      "type": "credit",
					      "category": "restaurants",
					      "description": "Merchant 3, refund",
					      "amount": 20
					    },
					    {
					      "account": "4352-3423-1234-5239",
					      "date": "2016-04-28",
					      "type": "debit",
					      "category": "retail",
					      "description": "Merchant 4, retail",
					      "amount": -234
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-01-20T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 230.45
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-01-22T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -100
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-03-20T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -5
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-03-22T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 952
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-03-22T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 952
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-03-23T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 111.11
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-03-24T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 500
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-04-15T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -60
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-04-16T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 50
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-04-25T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 20
					    },
					    {
					      "account": "258293-832",
					      "date": "2016-04-26T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -40
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-01-20T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 230.45
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-01-22T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -100
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-02-05T10:34:31Z",
					      "type": "check",
					      "category": "check",
					      "description": "Check",
					      "amount": -30.45
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-03-20T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -10
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-03-22T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 952
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-03-22T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 962
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-03-23T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 111.11
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-03-24T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 500
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-04-02T10:34:31Z",
					      "type": "check",
					      "category": "check",
					      "description": "Check",
					      "amount": -250.55
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-04-15T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -60
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-04-16T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 50
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-04-25T10:34:31Z",
					      "type": "deposit",
					      "category": "deposit",
					      "description": "Deposit",
					      "amount": 20
					    },
					    {
					      "account": "903423-123",
					      "date": "2016-04-26T10:34:31Z",
					      "type": "withdrawal",
					      "category": "withdrawal",
					      "description": "Withdrawal",
					      "amount": -40
					    }
					  ]
					};
			}
		}
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/BankingApi/accounts/:id', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = {
					  "type": "credit card",
					  "id": "4352-3423-1234-5239",
					  "limit": 5000
					};
			}
		}
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/BankingApi/accounts/:id/balance', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = {
					  "type": "credit card",
					  "id": "4352-3423-1234-5239",
					  "balance": 2334.56,
					  "limit": 2665.44
					};
			}
		}
		res.status(statusCode).send(result);
	});

	service.get('/mobile/custom/BankingApi/accounts/:id/transactions/:tid', function(req,res) {
		var result = {};
		var statusCode = 200;
		if (statusCode == 200){
			var acceptType = req.accepts(['application/json']);
			if (acceptType == 'application/json'){
				result = {
					  "date": "2016-01-20",
					  "type": "payment",
					  "category": "billing cycle",
					  "description": "Payment for 01/15 billing cycle",
					  "amount": 230.45
					};
			}
		}
		res.status(statusCode).send(result);
	});

};
