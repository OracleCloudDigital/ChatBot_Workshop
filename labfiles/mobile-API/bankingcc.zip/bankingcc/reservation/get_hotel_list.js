"use strict";

var log4js = require('log4js');
var logger = log4js.getLogger();
var moment = require('moment');


module.exports = {

    metadata: function metadata() {
        return {
            "name": "HotelList",
            "properties": {
            },
            "supportedActions": []
        };
    },

    invoke: (conversation, done) => {

        conversation.reply({ text: 'call hotel list start'});
        var temp =    conversation.mobileSdk;
        conversation.reply({ text: JSON.stringify(temp)});

        // conversation.mobileSdk.connectors.get("hotelServiceConnector", "sample").then(
        //   //  conversation.reply({ text: "here we go23131231"});
        // var temp =    conversation.mobileSdk;
        // conversation.reply({ text: JSON.stringify(temp)});

        // function (result) {
        //     try {
        //         conversation.reply({ text: "here we go!!!!"});

        //     }catch (err){
        //         conversation.reply({ text: "errer"});
        //     }                    
        // },function (error) {
        //     conversation.reply({ text: "error" });
        // })
            

        conversation.transition();
        done();
    }
};